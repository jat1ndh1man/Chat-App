self.addEventListener("push", (event) => {
  const data = event.data ? event.data.json() : {};
  
  self.registration.showNotification(data.title || "New Notification", {
    body: data.body || "You have a new message!",
    icon: "/icon.png",
    badge: "/icon.png",
  });
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    clients.openWindow("/") // Change to the chat page if needed
  );
});
