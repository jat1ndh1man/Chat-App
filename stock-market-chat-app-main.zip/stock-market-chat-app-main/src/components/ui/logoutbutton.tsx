import { useRouter } from "next/navigation"; // For redirection
import { createClient } from "@supabase/supabase-js";
import { BiLogOut } from "react-icons/bi";

const supabase = createClient("YOUR_SUPABASE_URL", "YOUR_SUPABASE_ANON_KEY");

const LogoutButton = () => {
  const router = useRouter();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push("/"); // Redirect to home page after logout
  };

  return (
    <div className="p-2 mr-2 mb-2 cursor-pointer" onClick={handleLogout}>
      <BiLogOut className="size-6 text-red-600 ml-3 hover:scale-105" />
      <span className="text-white mr-2">Logout</span>
    </div>
  );
};

export default LogoutButton;
