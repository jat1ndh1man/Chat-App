"use client";

import React, { useState, useEffect } from 'react';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { CiSearch } from 'react-icons/ci';

// 1. Initialize the Supabase client
const supabaseUrl = 'https://ydlauzejarqzvyvohbrd.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlkbGF1emVqYXJxenZ5dm9oYnJkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzg1NjI2MTMsImV4cCI6MjA1NDEzODYxM30.FVW7i_Gp8bMhdKNl5bBsXEosYVgfGa-L038ClYDT1Ds';
const supabase: SupabaseClient = createClient(supabaseUrl, supabaseKey);

// Update the Profile interface to include organisation
interface Profile {
  id: number;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  avatar_url: string | null;
  uuid: string | null;
  organisation: string | null;
}

// 4. Main component
const ContactsSearch: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [contacts, setContacts] = useState<Profile[]>([]);
  const router = useRouter();

  // Fetch contacts based on the search term
  const fetchContacts = async (term: string) => {
    try {
      // If there's no search term, clear the contacts
      if (!term.trim()) {
        setContacts([]);
        return;
      }

      // Query the 'profiles' table
      let query = supabase.from('profiles').select('*');

      // Apply case-insensitive filter on full_name
      query = query.ilike('full_name', `%${term}%`);

      const { data, error } = await query;
      if (error) {
        console.error('Error fetching contacts:', error);
        return;
      }

      if (data) {
        setContacts(data);
      }
    } catch (err) {
      console.error('Unexpected error fetching contacts:', err);
    }
  };

  // Debounce calls to fetchContacts when searchTerm changes
  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      fetchContacts(searchTerm);
    }, 50);

    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm]);

  // Handle clicking a user result
  const handleSelectContact = (contact: Profile) => {
    router.push(`/chats/${contact.id}`);
  };

  return (
    <div className="relative max-w-[400px] mx-auto">
      <CiSearch className="absolute right-2 mt-3 flex size-6 items-center pointer-events-none text-gray-400" />
      <input
        type="text"
        placeholder="Search User..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="p-3 w-full bg-slate-700 text-gray-200 rounded-xl focus:outline-none focus:ring-2 shadow-md focus:ring-slate-500 transition"
      />

      {/* Show dropdown if a search term is entered */}
      {searchTerm && (
        <ul className="absolute top-[60px] left-0 w-full bg-slate-700 rounded-xl text-gray-300 shadow-lg list-none m-0 p-0 z-[1000]">
          {contacts.length > 0 ? (
            contacts.map((contact) => (
              <li
                key={contact.id}
                onClick={() => handleSelectContact(contact)}
                className="p-3 cursor-pointer hover:bg-slate-500 rounded-xl  hover:text-white transition-colors flex items-center space-x-3"
              >
                {contact.avatar_url && (
                  <Image
                    src={contact.avatar_url}
                    alt="User avatar"
                    width={32}
                    height={32}
                    className="w-8 h-8 rounded-full object-cover"
                  />
                )}
                <div>
                  <span>{contact.full_name ?? 'No Name'}</span>
                  {contact.organisation && (
                    <p className="text-xs text-gray-400">{contact.organisation}</p>
                  )}
                </div>
              </li>
            ))
          ) : (
            <li className="p-3 text-center text-gray-400">No matching users</li>
          )}
        </ul>
      )}
    </div>
  );
};

export default ContactsSearch;
