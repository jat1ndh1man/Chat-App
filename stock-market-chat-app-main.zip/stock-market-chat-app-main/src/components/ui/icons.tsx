import { Moon, SunMedium, Twitter, Loader2, Github } from "lucide-react"

export const Icons = {
  sun: SunMedium,
  moon: Moon,
  twitter: Twitter,
  gitHub: Github,
  spinner: Loader2,
}

