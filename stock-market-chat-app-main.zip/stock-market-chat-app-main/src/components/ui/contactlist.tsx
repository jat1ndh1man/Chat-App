'use client';
import { useRouter } from "next/navigation"; // Use this for app router
import Image from "next/image";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const ContactList = ({ contacts, userId }: { contacts: any[]; userId: string }) => {
  const router = useRouter();

  // Find the current user's organisation from the contacts list
  const currentUser = contacts.find(contact => contact.id === userId);
  const userOrganisation = currentUser ? currentUser.organisation : null;

  const openChat = (contactId: string) => {
    router.push(`/chats/${contactId}`);
  };

  // Filter out the current user and any contacts not in the same organisation
  const filteredContacts = contacts.filter(
    contact => contact.id !== userId && contact.organisation === userOrganisation
  );

  return (  
    <div className="w-full h-100 rounded-xl">
      {filteredContacts.length === 0 ? (
        <p className="text-gray-500">No contacts found</p>
      ) : (
        filteredContacts.map((contact) => (
          <div
            key={contact.id}
            onClick={() => openChat(contact.id)}
            className="flex items-center p-4 border-gray-500 shadow-md mb-3 rounded-xl cursor-pointer hover:bg-slate-600"
          >
            <Image
              src={contact.avatar_url || "/default-avatar.png"}
              alt={contact.name || "Name"}
              width={40}
              height={40}
              className="rounded-full size-5 mr-3"
            />
            <div className="flex flex-col whitespace-nowrap">
              <p className="size-6 flex-nowrap text-white">{contact.full_name}</p>
              <span className="text-gray-400 text-sm">{contact.organisation}</span>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default ContactList;
