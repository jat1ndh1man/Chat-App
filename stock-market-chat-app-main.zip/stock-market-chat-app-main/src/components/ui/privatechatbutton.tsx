"use client";

import { useRouter } from "next/navigation";

const PrivateChatButton = ({ userId, contactId }: { userId: string; contactId: string }) => {
  const router = useRouter();

  const startPrivateChat = async () => {
    const response = await fetch("/api/chats/room", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, contactId }),
    });

    const { roomId } = await response.json();
    router.push(`/chat/${roomId}`);
  };

  return <button onClick={startPrivateChat}>Start Private Chat</button>;
};

export default PrivateChatButton;
