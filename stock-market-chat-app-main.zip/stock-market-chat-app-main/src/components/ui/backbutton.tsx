"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react"; // Import arrow icon

const BackButton = () => {
  const router = useRouter();

  return (
    <button
      onClick={() => router.push("/chats")} // Navigate to chats page
      className="flex items-center gap-2 p-2 rounded-full bg-gray-700 hover:bg-gray-600 text-white"
    >
      <ArrowLeft size={20} />
    </button>
  );
};

export default BackButton;
