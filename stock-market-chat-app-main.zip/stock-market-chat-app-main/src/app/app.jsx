
async function init() {
    const {data:  messages, error} = await supabase
    .from('messages')
    .select('*')

}
console.log(messages);
import { useEffect } from "react";

export default function App({ Component, pageProps }) {
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch((err) => console.error("Service Worker registration failed:", err));
    }
  }, []);

  return <Component {...pageProps} />;
}
