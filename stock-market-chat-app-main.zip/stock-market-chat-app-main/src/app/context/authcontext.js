// "use client";

// import { createContext, useContext, useEffect, useState } from "react";
// import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

// const AuthContext = createContext(null); // ✅ Set initial value to null

// export function AuthProvider({ children }) {
//   const supabase = createClientComponentClient(); 
//   const [user, setUser] = useState(null);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     const fetchUser = async () => {
//       try {
//         const { data, error } = await supabase.auth.getUser();
//         if (error) throw error;
//         setUser(data.user);
//       } catch (err) {
//         console.error("Error fetching user:", err);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchUser();

//     const { data: authListener } = supabase.auth.onAuthStateChange((_, session) => {
//       setUser(session?.user || null);
//     });

//     return () => {
//       authListener?.subscription?.unsubscribe();
//     };
//   }, []);

//   return (
//     <AuthContext.Provider value={{ user, loading }}>
//       {children}
//     </AuthContext.Provider>
//   );
// }

// // ✅ Correctly return the context and ensure it’s not null
// export function useAuth() {
//   const context = useContext(AuthContext);
//   if (!context) {
//     throw new Error("useAuth must be used within an AuthProvider");
//   }
//   return context;
// }
