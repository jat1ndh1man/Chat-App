"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/labels";
import { FaPhoneAlt } from "react-icons/fa";
import { supabase } from "../lib/supabaseClient";

// Professional spinner component using a conic gradient with navy, black and white shades
function ProfessionalSpinner() {
  return (
    <>
      <div className="w-16 h-16 rounded-full animate-spin-professional" />
      <style jsx>{`
        @keyframes spin-professional {
          0% {
            transform: rotate(0deg);
          }
          100% {
            transform: rotate(360deg);
          }
        }
        .animate-spin-professional {
          background: conic-gradient(
            #001f3f, /* Navy */
            #000000, /* Black */
            #ffffff, /* White */
            #001f3f  /* Navy again for a smooth loop */
          );
          -webkit-mask: radial-gradient(
            farthest-side,
            transparent calc(100% - 8px),
            black 100%
          );
          mask: radial-gradient(
            farthest-side,
            transparent calc(100% - 8px),
            black 100%
          );
          animation: spin-professional 1s linear infinite;
        }
      `}</style>
    </>
  );
}

type UserAuthFormProps = React.HTMLAttributes<HTMLDivElement>;

export function UserAuthForm({ className, ...props }: UserAuthFormProps) {
  const [isLoading, setIsLoading] = React.useState(false);
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [fullName, setFullName] = React.useState("");
  const [usePhone, setUsePhone] = React.useState(false);
  const [message, setMessage] = React.useState("");
  const [isSignUp, setIsSignUp] = React.useState(false);
  const router = useRouter();

  async function onSubmit(event: React.SyntheticEvent) {
    event.preventDefault();
    setIsLoading(true);
    setMessage("");

    let result;
    if (isSignUp) {
      result = usePhone
        ? await supabase.auth.signUp({
            phone,
            password,
            options: { data: { full_name: fullName } },
          })
        : await supabase.auth.signUp({
            email,
            password,
            options: { data: { full_name: fullName } },
          });

      if (result.data.user) {
        const { error: profileError } = await supabase.from("profiles").insert([
          {
            id: result.data.user.id,
            full_name: fullName,
            email: email || null,
            phone: phone || null,
            updated_at: new Date().toISOString(),
          },
        ]);

        if (profileError) {
          setMessage(profileError.message);
          setIsLoading(false);
          return;
        }
      }
    } else {
      result = usePhone
        ? await supabase.auth.signInWithOtp({ phone })
        : await supabase.auth.signInWithPassword({ email, password });
    }

    const { error } = result;
    if (error) {
      setMessage(error.message);
      setIsLoading(false);
      return;
    }

    if (isSignUp) {
      setMessage("Sign-up successful! Check your email/phone.");
      setIsLoading(false);
    } else {
      // For login, keep the loader active until navigation.
      setTimeout(() => router.push("/chats"), 1000);
      return;
    }
  }

  // 🔐 Logout Function
  async function handleLogout() {
    const { error } = await supabase.auth.signOut();
    if (!error) {
      router.push("/login");
    }
  }

  return (
    <div className={cn("relative grid gap-6", className)} {...props}>
      {isLoading && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70">
          <ProfessionalSpinner />
        </div>
      )}
      <form onSubmit={onSubmit} className={isLoading ? "opacity-50 pointer-events-none" : ""}>
        <div className="grid gap-2">
          {isSignUp && (
            <div className="grid gap-1">
              <Label className="sr-only" htmlFor="fullName">
                Full Name
              </Label>
              <Input
                id="fullName"
                placeholder="Full Name"
                type="text"
                autoComplete="name"
                disabled={isLoading}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
              />
            </div>
          )}
          <div className="grid gap-1">
            <Label className="sr-only" htmlFor="emailOrPhone">
              {usePhone ? "Phone Number" : "Email"}
            </Label>
            <Input
              id="emailOrPhone"
              placeholder={usePhone ? "Phone Number" : "name@example.com"}
              type={usePhone ? "tel" : "email"}
              autoComplete={usePhone ? "tel" : "email"}
              disabled={isLoading}
              value={usePhone ? phone : email}
              onChange={(e) =>
                usePhone ? setPhone(e.target.value) : setEmail(e.target.value)
              }
            />
          </div>
          <div className="grid gap-1">
            <Label className="sr-only" htmlFor="password">
              Password
            </Label>
            <Input
              id="password"
              placeholder="Password"
              type="password"
              autoComplete="current-password"
              disabled={isLoading}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <Button type="submit" disabled={isLoading}>
            {isSignUp ? "Sign Up" : usePhone ? "Send OTP" : "Sign In"}
          </Button>
          {message && <p className="text-red-500 mt-2">{message}</p>}
        </div>
      </form>
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-background px-2">Or continue with</span>
        </div>
      </div>
      <Button
        variant="outline"
        type="button"
        disabled={isLoading}
        onClick={() => setUsePhone(!usePhone)}
      >
        <FaPhoneAlt className="mr-2 h-4 w-4" />
        {usePhone ? "Use Email Instead" : "Phone Number"}
      </Button>
      <Button
        variant="link"
        type="button"
        className="mt-2"
        onClick={() => setIsSignUp(!isSignUp)}
      >
        {isSignUp ? "Already have an account? Sign In" : "Don't have an account? Sign Up"}
      </Button>
      <Button variant="outline" onClick={handleLogout} className="mt-2">
        Logout
      </Button>
    </div>
  );
}
