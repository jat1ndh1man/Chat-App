"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export default function JoinPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      router.push(user ? "/chats" : "/");
    };

    checkUser().finally(() => setLoading(false));
  }, [router]);

  return (
    <div className="flex items-center justify-center h-screen">
      {loading ? (
        <div className="text-xl font-semibold">Redirecting...</div>
      ) : null}
    </div>
  );
}
