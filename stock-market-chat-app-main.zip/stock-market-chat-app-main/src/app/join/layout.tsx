// app/join/layout.tsx
import React from 'react';

export default function JoinLayout({
  children, // This will be the page content (e.g., [roomID]/page.tsx)
}: {
  children: React.ReactNode;
}) {
  return (
    <div>
      <header className='bg-black h-max flex items-center justify-center'>
        <h1 className='text-3xl font-bold  text-white flex justify-between m-4'>StockMarket Chat App</h1>
      </header>
      <main>{children}</main> {/* This is where the dynamic page content will render */}
      <footer>
        <p className='text-white bg-black z-1 '>© 2025 StockMarket Chat App</p>
      </footer>
    </div>
  );
}