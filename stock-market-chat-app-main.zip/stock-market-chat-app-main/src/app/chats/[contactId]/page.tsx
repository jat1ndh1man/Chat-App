"use client";

import { useState, useEffect, useRef, ChangeEvent } from "react";
import { useParams } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { IoMdSend } from "react-icons/io";
import { motion } from "framer-motion";
import { FaBell, FaCalendarAlt } from "react-icons/fa";
import { IoLink } from "react-icons/io5";
import { ImAttachment, ImVolumeMute2 } from "react-icons/im";
import { MdInfo,  } from "react-icons/md";
import { toast } from "react-toastify";
import BackButton from "@/components/ui/backbutton";

interface Message {
  id: string;
  content: string;
  sender: string;
  receiver: string;
  created_at: string;
  attachment_url?: string;
}

function ProfessionalSpinner() {
  return (
    <>
      <div className="w-16 h-16 rounded-full animate-spin-professional" />
      <style jsx>{`
        @keyframes spin-professional {
          0% {
            transform: rotate(0deg);
          }
          100% {
            transform: rotate(360deg);
          }
        }
        .animate-spin-professional {
          background: conic-gradient(
            #001f3f,
            #000000,
            #ffffff,
            #001f3f
          );
          -webkit-mask: radial-gradient(
            farthest-side,
            transparent calc(100% - 8px),
            black 100%
          );
          mask: radial-gradient(
            farthest-side,
            transparent calc(100% - 8px),
            black 100%
          );
          animation: spin-professional 1s linear infinite;
        }
      `}</style>
    </>
  );
}

function Loader() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-800">
      <ProfessionalSpinner />
      <h2 className="mt-4 text-white text-xl font-semibold">Loading Chat...</h2>
    </div>
  );
}

export default function PrivateChat() {
  const { contactId } = useParams();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [userId, setUserId] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const [contactName, setContactName] = useState<string | null>(null);
  const [contactAvatar, setContactAvatar] = useState<string | null>(null);

  const scrollToBottom = () => {
    requestAnimationFrame(() => {
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({ behavior: "smooth", block: "nearest" });
      }
    });
  };

  useEffect(() => {
    const getUser = async () => {
      const { data, error } = await supabase.auth.getUser();
      if (error) {
        console.error("Error fetching user:", error.message);
        return;
      }
      if (data.user) setUserId(data.user.id);
    };
    getUser();
  }, []);

  useEffect(() => {
    if (!contactId || !userId) return;

    const fetchMessages = async () => {
      try {
        // Load messages from localStorage first
        const storedMessages = localStorage.getItem(`messages_${userId}_${contactId}`);
        const localMessages: Message[] = storedMessages ? JSON.parse(storedMessages) : [];

        // Fetch messages from Supabase
        const { data, error } = await supabase
          .from("messages")
          .select("*")
          .or(
            `and(sender.eq.${userId},receiver.eq.${contactId}),and(sender.eq.${contactId},receiver.eq.${userId})`
          )
          .order("created_at", { ascending: true });

        if (error) {
          console.error("Error fetching messages:", error.message);
          return;
        }

        const supabaseMessages = data || [];

        // Merge local and Supabase messages while ensuring uniqueness
        const messagesMap = new Map();
        [...localMessages, ...supabaseMessages].forEach((msg) => messagesMap.set(msg.id, msg));
        const uniqueMessages = Array.from(messagesMap.values());

        // Update state and persist unique messages
        setMessages(uniqueMessages);
        localStorage.setItem(`messages_${userId}_${contactId}`, JSON.stringify(uniqueMessages));
        scrollToBottom();
      } catch (err) {
        console.error("Unexpected error fetching messages:", err);
      }
    };

    fetchMessages();
  }, [contactId, userId]);

  useEffect(() => {
    if (!contactId || !userId) return;

    const channel = supabase
      .channel(`messages:${userId}:${contactId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages" },
        (payload) => {
          setMessages((prevMessages) => {
            const newMessageData = payload.new as Message;
            if (prevMessages.some((msg) => msg.id === newMessageData.id)) {
              return prevMessages;
            }
            // Play notification sound if the message is not sent by the current user
            if (newMessageData.sender !== userId) {
              const audio = new Audio('/notification.mp3');
              audio.play().catch((error) => {
                console.error("Error playing audio:", error);
              });
            }
            const updatedMessages = [...prevMessages, newMessageData];
            localStorage.setItem(`messages_${userId}_${contactId}`, JSON.stringify(updatedMessages));
            scrollToBottom();
            return updatedMessages;
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [contactId, userId]);

  useEffect(() => {
    const fetchContactDetails = async () => {
      if (!contactId) return;
      const { data, error } = await supabase
        .from("profiles")
        .select("full_name, avatar_url")
        .eq("id", contactId)
        .single();

      if (error) {
        console.error("Error fetching contact details:", error.message);
      } else {
        setContactName(data.full_name);
        setContactAvatar(data.avatar_url);
      }
    };

    fetchContactDetails();
  }, [contactId]);

  const sendMessage = async () => {
    if (!newMessage.trim() && !file) return;
    let attachmentUrl = null;

    if (file) {
      setIsUploading(true);
      const filePath = `attachments/${Date.now()}_${file.name}`;
      const { error } = await supabase.storage.from("chat-attachments").upload(filePath, file);

      if (error) {
        console.error("Error uploading file:", error.message);
        setIsUploading(false);
        return;
      }

      // Retrieve the public URL
      attachmentUrl = supabase.storage.from("chat-attachments").getPublicUrl(filePath);
      setIsUploading(false);
    }

    const { error } = await supabase.from("messages").insert([
      {
        content: newMessage,
        sender: userId,
        receiver: contactId,
        created_at: new Date().toISOString(),
        attachment_url: attachmentUrl,
      },
    ]);

    if (error) {
      console.error("Error sending message:", error.message);
    } else {
      setFile(null);
      setNewMessage("");
      scrollToBottom();
    }
  };

  const handleFileChange = async (event: ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files || event.target.files.length === 0 || isUploading) return;
    const file = event.target.files[0];
    setIsUploading(true);

    const filePath = `attachments/${Date.now()}-${file.name}`;
    toast.info(`Uploading ${file.name}...`, { autoClose: 2000 });

    try {
      const { error } = await supabase.storage.from("chat-attachments").upload(filePath, file, {
        cacheControl: "3600",
        upsert: false,
      });

      if (error) {
        toast.error(`Upload failed: ${error.message}`, { autoClose: 3000 });
        setIsUploading(false);
        return;
      }

      const { data: { publicUrl } } = supabase.storage.from("chat-attachments").getPublicUrl(filePath);
      if (!userId) {
        toast.error("You must be logged in to send attachments.", { autoClose: 3000 });
        setIsUploading(false);
        return;
      }

      const { data: newMessageData, error: insertError } = await supabase
        .from("messages")
        .insert([
          {
            content: publicUrl,
            sender: userId,
            receiver: contactId,
            attachment_url: publicUrl,
            created_at: new Date().toISOString(),
          },
        ])
        .select()
        .single();

      if (insertError) {
        toast.error(`Error saving message: ${insertError.message}`, { autoClose: 3000 });
      } else {
        toast.success("File uploaded and sent successfully!", { autoClose: 3000 });
        setMessages((prevMessages) => [...prevMessages, newMessageData]);
      }
    } catch (err) {
      console.error("Unexpected error:", err);
      toast.error("Unexpected error. Check console.", { autoClose: 3000 });
    } finally {
      setIsUploading(false);
      event.target.value = "";
    }
  };

  if (!userId) {
    return <Loader />;
  }

  return (
    <div className="flex h-screen bg-gray-800 text-white">
      {/* Chat Area */}
      <div className="flex flex-col flex-1">
        {/* Header */}
        <div className="p-4 bg-gray-800 shadow-xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BackButton />
            <Avatar className="size-8">
              <AvatarImage src={contactAvatar || "https://via.placeholder.com/150"} />
              <AvatarFallback className="bg-gray-700">{contactName ? contactName.charAt(0) : ""}</AvatarFallback>
            </Avatar>
            <h2 className="text-lg font-bold">{contactName}</h2>
          </div>
          <div className="flex items-end gap-2">
            {/* <MdVideoCall className="size-9 bg-gray-700 text-gray-400 rounded-full p-1 shadow-md hover:bg-slate-600" />
            <IoIosCall className="size-9 bg-gray-700 text-gray-400 rounded-full p-1 shadow-md hover:bg-slate-600" /> */}
            <button
              className="size-9 bg-gray-700 text-gray-800 font-semibold rounded-full shadow-md hover:bg-slate-600 transition"
              onClick={() => setIsOpen(true)}
            >
              <MdInfo className="text-gray-400 size-6 m-1.5" />
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin scrollbar-thumb-gray-600">
          {messages.map((msg, index) => (
            <div
              key={msg.id || `message-${index}`}
              className={`p-3 rounded-xl max-w-xs ${msg.sender === userId ? "bg-slate-700 ml-auto" : "bg-slate-600"}`}
            >
              {msg.attachment_url ? (
                <img src={msg.attachment_url} alt="Attachment" className="max-w-full rounded-lg" />
              ) : (
                <p className="text-sm">{msg.content}</p>
              )}
              <div ref={messagesEndRef}></div>
            </div>
          ))}
        </div>

        {/* Message Input */}
        <div className="p-4 bg-gray-800 flex items-center gap-2">
          <input
            type="text"
            className="flex-1 p-2 bg-gray-700 rounded-xl text-white focus:outline-none"
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          />
          <input type="file" ref={fileInputRef} style={{ display: "none" }} onChange={handleFileChange} />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="bg-slate-700 p-2 hover:scale-110 rounded-2xl text-xl shadow-md text-white"
          >
            <ImAttachment />
          </button>
          <button className="bg-green-800 text-white px-4 py-2 rounded-2xl font-semibold shadow-md hover:scale-105" onClick={sendMessage}>
            Send <IoMdSend className="inline ml-1" />
          </button>
        </div>
      </div>

      {/* Chat Details Sidebar */}
      <motion.div
        initial={{ x: "100%" }}
        animate={{ x: isOpen ? "0%" : "100%" }}
        exit={{ x: "100%" }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        className="bg-[#0D0D0D] w-[20%] shadow-2xl fixed right-0 h-full p-5 border-l border-gray-800 z-50 rounded-s-xl"
      >
        <div className="flex justify-between items-center border-b border-gray-700 pb-3">
          <h1 className="text-white font-semibold text-xl tracking-wide">Chat Details</h1>
          <button className="text-gray-400 hover:text-red-500 transition duration-200 text-lg" onClick={() => setIsOpen(false)}>
            ✖
          </button>
        </div>

        <div className="grid grid-cols-4 gap-4 justify-center mt-6">
          {[
            { icon: <FaBell className="size-6" /> },
            { icon: <FaCalendarAlt className="size-6" /> },
            { icon: <IoLink className="size-6" /> },
            { icon: <ImVolumeMute2 className="size-6" /> },
          ].map(({ icon }, idx) => (
            <button
              key={idx}
              className="bg-gray-800/70 p-3 rounded-xl text-white hover:bg-gray-700 transition duration-300 shadow-md hover:shadow-lg flex flex-col items-center"
            >
              {icon}
            </button>
          ))}
        </div>

        <div className="mt-6 bg-gray-900/40 p-4 rounded-lg shadow-lg">
          <div className="flex justify-between items-center text-gray-300 text-sm">
            <h2 className="font-semibold">
              Shared Media <span className="text-gray-500">23</span>
            </h2>
            <button className="text-blue-400 hover:underline text-sm">See all</button>
          </div>
        </div>

        <div className="mt-6 bg-gray-900/40 p-4 rounded-lg shadow-lg">
          <div className="flex justify-between items-center text-gray-300 text-sm">
            <h2 className="font-semibold">
              Photos and Videos <span className="text-gray-500">23</span>
            </h2>
            <button className="text-blue-400 hover:underline text-sm">See all</button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
