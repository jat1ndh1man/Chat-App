import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { getPrivateMessages, sendPrivateMessage } from "@/lib/supabase";
import { useUser } from "@supabase/auth-helpers-react";

const PrivateChat = () => {
  const router = useRouter();
  const contactId = String(router.query.contactId);
  const user = useUser();

  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");

  useEffect(() => {
    if (user && contactId) {
      loadMessages();
    }
  }, [user, contactId, loadMessages]);

  const loadMessages = useCallback(async () => {
    if (!user) return;
    const data = await getPrivateMessages(user.id, contactId);
    setMessages(data);
  });

  const handleSend = async () => {
    if (!user || !newMessage.trim()) return;

    await sendPrivateMessage(user.id, contactId, newMessage);
    setNewMessage("");
    loadMessages();
  };

  return (
    <div className="p-4">
      <h2>Chat with {contactId}</h2>
      <div className="border p-2 h-96 overflow-y-auto">
        {messages.map((msg) => (
          <div key={msg.id} className={`p-2 ${msg.sender_id === user?.id ? "text-right" : "text-left"}`}>
            <p className="inline-block p-2 rounded bg-gray-200">{msg.message}</p>
          </div>
        ))}
      </div>
      <div className="mt-2">
        <input
          className="w-full border p-2"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type a message..."
        />
        <button className="mt-2 bg-blue-500 text-white px-4 py-2" onClick={handleSend}>
          Send
        </button>
      </div>
    </div>
  );
};

export default PrivateChat;
