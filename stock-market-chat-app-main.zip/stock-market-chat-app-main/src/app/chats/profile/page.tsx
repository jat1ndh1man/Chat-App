"use client";

import React, { useEffect, useState, ChangeEvent } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import { User } from "@supabase/supabase-js";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// Replace these imports with your actual UI components:
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/labels";
import { FaCamera, FaArrowLeft, FaTimes } from "react-icons/fa";

// Professional spinner component using a conic gradient with navy, black and white shades
function ProfessionalSpinner() {
  return (
    <>
      <div className="w-16 h-16 rounded-full animate-spin-professional" />
      <style jsx>{`
        @keyframes spin-professional {
          0% {
            transform: rotate(0deg);
          }
          100% {
            transform: rotate(360deg);
          }
        }
        .animate-spin-professional {
          background: conic-gradient(
            #001f3f, /* Navy */
            #000000, /* Black */
            #ffffff, /* White */
            #001f3f  /* Navy again for a smooth loop */
          );
          -webkit-mask: radial-gradient(
            farthest-side,
            transparent calc(100% - 8px),
            black 100%
          );
          mask: radial-gradient(
            farthest-side,
            transparent calc(100% - 8px),
            black 100%
          );
          animation: spin-professional 1s linear infinite;
        }
      `}</style>
    </>
  );
}

// Helper function to validate the new password
function isValidPassword(password: string): boolean {
  return password.length >= 6 && /[A-Za-z]/.test(password) && /[0-9]/.test(password);
}

export default function ProfilePage() {
  const router = useRouter();

  // Loading state for blocking interactions & showing spinners if needed
  const [loading, setLoading] = useState(false);

  // Basic user info from Supabase Auth (properly typed)
  const [user, setUser] = useState<User | null>(null);

  // Profile fields from "profiles" table
  const [fullName, setFullName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [organisation, setOrganisation] = useState("");

  // Auth fields (email, password)
  const [email, setEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");

  // Fetch the current user & profile on component mount
  useEffect(() => {
    fetchUserAndProfile();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function fetchUserAndProfile() {
    setLoading(true);

    // 1) Get currently authenticated user
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      router.push("/login");
      setLoading(false);
      return;
    }

    setUser(user);
    setEmail(user.email || "");

    // 2) Fetch the profile row from "profiles" table including organisation
    const { data: profileData, error: profileError } = await supabase
      .from("profiles")
      .select("full_name, avatar_url, organisation")
      .eq("id", user.id)
      .single();

    if (profileData) {
      setFullName(profileData.full_name || "");
      setAvatarUrl(profileData.avatar_url || "");
      setOrganisation(profileData.organisation || "");
    }

    if (profileError) {
      console.error("Profile fetch error:", profileError.message);
    }

    setLoading(false);
  }

  /**
   * Handle updating user profile (avatar, organisation) plus email in Auth.
   * If email is changed, a confirmation prompt will ask the user to verify.
   * Note: Username (fullName) is no longer editable on this page.
   */
  async function handleUpdateProfile() {
    try {
      setLoading(true);
      let success = true;

      // 1) Update the user email in Supabase Auth (if changed)
      if (email && user && email !== user.email) {
        // Prompt the user about the verification email
        const confirmed = window.confirm(
          "Your email will be updated and a verification email will be sent to your new email address. Do you want to proceed?"
        );
        if (!confirmed) {
          toast.info("Email update cancelled");
          success = false;
        } else {
          const { error: updateUserError } = await supabase.auth.updateUser({
            email,
          });
          if (updateUserError) {
            console.error("Error updating email in Auth:", updateUserError.message);
            toast.error("Invalid email. Please check your email address.");
            success = false;
          }
        }
      }

      // 2) Update the "profiles" table with avatar_url and organisation.
      // Username (fullName) is no longer updated.
      if (user) {
        const { error: profileError } = await supabase
          .from("profiles")
          .update({
            avatar_url: avatarUrl,
            organisation,
            updated_at: new Date().toISOString(),
          })
          .eq("id", user.id);

        if (profileError) {
          console.error("Error updating profile:", profileError.message);
          toast.error("Failed to update profile.");
          success = false;
        }
      }

      if (success) {
        toast.success("Profile updated successfully");
      }
    } finally {
      setLoading(false);
    }
  }

  /**
   * Handle password change via Supabase Auth.
   * Validates that the password is at least 6 characters long and contains both letters and numbers.
   */
  async function handleChangePassword() {
    if (!newPassword) return;
    if (!isValidPassword(newPassword)) {
      toast.error("Password must be at least 6 characters and include both letters and numbers.");
      return;
    }
    setLoading(true);

    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
      console.error("Error updating password:", error.message);
      toast.error("Failed to update password.");
    } else {
      toast.success("Password updated successfully");
    }

    setNewPassword("");
    setLoading(false);
  }

  /**
   * Handle avatar upload to Supabase Storage ("avatars" bucket).
   */
  async function handleAvatarChange(e: ChangeEvent<HTMLInputElement>) {
    try {
      if (!e.target.files || e.target.files.length === 0) {
        return;
      }
      setLoading(true);

      const file = e.target.files[0];
      const fileExt = file.name.split(".").pop();
      if (!user) return;

      const fileName = `${user.id}.${fileExt}`;
      const filePath = `public/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from("avatars")
        .upload(filePath, file, { upsert: true });

      if (uploadError) {
        console.error("Error uploading avatar:", uploadError.message);
        toast.error("Avatar upload failed.");
        return;
      }

      // Get the public URL and append a cache-busting query parameter
      const { data } = supabase.storage.from("avatars").getPublicUrl(filePath);
      const updatedPublicUrl = data.publicUrl + `?t=${new Date().getTime()}`;

      setAvatarUrl(updatedPublicUrl);

      const { error: updateProfileError } = await supabase
        .from("profiles")
        .update({ avatar_url: updatedPublicUrl })
        .eq("id", user.id);

      if (updateProfileError) {
        console.error("Error updating profile with avatar:", updateProfileError.message);
        toast.error("Failed to update avatar.");
      } else {
        toast.success("Avatar updated successfully");
      }
    } finally {
      setLoading(false);
    }
  }

  /**
   * Handle removal of avatar.
   * Updates the "profiles" table by setting the avatar_url to null.
   */
  async function handleRemoveAvatar() {
    if (!user) return;
    setLoading(true);

    const { error } = await supabase
      .from("profiles")
      .update({ avatar_url: null, updated_at: new Date().toISOString() })
      .eq("id", user.id);

    if (error) {
      console.error("Error removing avatar:", error.message);
      toast.error("Failed to remove avatar.");
    } else {
      setAvatarUrl("");
      toast.success("Avatar removed successfully");
    }
    setLoading(false);
  }

  // Show full-screen loader if user is not loaded yet
  if (!user) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70">
        <ProfessionalSpinner />
      </div>
    );
  }

  return (
    <div className="bg-gray-800 text-white min-h-screen p-8 relative">
      {loading && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70">
          <ProfessionalSpinner />
        </div>
      )}

      <div className="max-w-2xl mx-auto">
        {/* Back button */}
        <Button
          onClick={() => router.push("/chats")}
          className="mb-6 bg-slate-600 hover:bg-slate-500 shadow-lg rounded-xl flex items-center"
        >
          <FaArrowLeft className="mr-2" /> Back
        </Button>

        <h1 className="text-2xl font-semibold mb-6">User Profile</h1>

        {/* Avatar & profile form */}
        <div className="space-y-6 mb-8 bg-gray-700 p-4 rounded-2xl shadow-xl">
          <div className="flex items-center space-x-4 relative">
            {/* Avatar preview */}
            <div className="relative w-24 h-24">
              {avatarUrl ? (
                <>
                  <img
                    src={avatarUrl}
                    alt="User Avatar"
                    className="rounded-full object-cover w-24 h-24"
                  />
                  {/* Cross icon overlay for removing avatar */}
                  <button
                    onClick={handleRemoveAvatar}
                    className="absolute top-0 right-0 bg-red-600 text-white rounded-full p-1 hover:bg-red-500"
                    title="Remove Avatar"
                  >
                    <FaTimes />
                  </button>
                </>
              ) : (
                <div className="bg-gray-600 rounded-full w-24 h-24 flex items-center justify-center text-xl">
                  No Avatar
                </div>
              )}
              {/* File input for uploading a new avatar */}
              <label
                htmlFor="avatarUpload"
                className="absolute bottom-0 right-0 p-2 bg-black/50 rounded-full cursor-pointer"
              >
                <FaCamera />
              </label>
              <input
                id="avatarUpload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleAvatarChange}
                disabled={loading}
              />
            </div>

            <div className="flex-1 space-y-4">
              <div>
                <Label className="mb-1">User Name</Label>
                <Input
                  type="text"
                  value={fullName}
                  readOnly
                  className="bg-gray-800 rounded-xl mt-1 p-4 w-full"
                />
              </div>
              <div>
                <Label className="mb-1">Email</Label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={loading}
                  className="bg-gray-800 rounded-xl mt-1 p-4 w-full"
                />
              </div>
              <div>
                <Label className="mb-1">Organisation</Label>
                <Input
                  type="text"
                  value={organisation}
                  onChange={(e) => setOrganisation(e.target.value)}
                  disabled={loading}
                  className="bg-gray-800 rounded-xl mt-1 p-4 w-full"
                />
              </div>
            </div>
          </div>

          <Button
            onClick={handleUpdateProfile}
            disabled={loading}
            className="bg-gray-800 hover:bg-slate-600 shadow-lg rounded-xl"
          >
            {loading ? "Updating..." : "Update Profile"}
          </Button>
        </div>

        {/* Password change form */}
        <div className="space-y-5 bg-gray-700 p-4 rounded-2xl shadow-xl">
          <div>
            <Label className="mb-3">New Password</Label>
            <Input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              disabled={loading}
              className="bg-gray-800 rounded-xl mt-1 p-4 text-white w-full"
            />
          </div>
          <Button
            onClick={handleChangePassword}
            disabled={loading || !newPassword}
            className="bg-gray-800 hover:bg-slate-700 shadow-lg rounded-xl"
          >
            {loading ? "Processing..." : "Change Password"}
          </Button>
        </div>
      </div>
      <ToastContainer position="top-center" autoClose={3000} />
    </div>
  );
}
