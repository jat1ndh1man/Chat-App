/* eslint-disable @typescript-eslint/no-unused-vars */
'use client'
import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { HiMiniChatBubbleLeftRight } from "react-icons/hi2";
import { MdSettings } from "react-icons/md";
import { BiLogOut } from "react-icons/bi";
import { BsChatSquareTextFill } from "react-icons/bs";
import { FaFolder } from "react-icons/fa6";
import { IoBookmarks } from "react-icons/io5";
import { HiUserGroup, HiMiniBellAlert } from "react-icons/hi2";
import { Button } from '@/components/ui/button';
import { RiChatNewLine } from "react-icons/ri";
import ContactList from '@/components/ui/contactlist';
import { getContacts } from "@/lib/supabase";
import ContactsSearch from '@/components/ui/ContactsSearch';
import { useRouter } from "next/navigation";
import { motion } from 'framer-motion';

const supabaseUrl = "https://ydlauzejarqzvyvohbrd.supabase.co";
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlkbGF1emVqYXJxenZ5dm9oYnJkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzg1NjI2MTMsImV4cCI6MjA1NDEzODYxM30.FVW7i_Gp8bMhdKNl5bBsXEosYVgfGa-L038ClYDT1Ds";
const supabase = createClient(supabaseUrl, supabaseKey);

type Contact = {
  id: string;
  name: string;
  lastMessage?: string;
};

interface Message {
  id: number;
  content: string;
  sender: string;
  created_at: string;
}

interface ExtendedUser {
  id: string;
  full_name: string;
  avatar_url: string;
}

const ChatApp = () => {
  // States
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [user, setUser] = useState<ExtendedUser | null>(null);
  const [profilesMap, setProfilesMap] = useState<{ [key: string]: string }>({});
  const [joinTime, setJoinTime] = useState<string | null>(null);
  const [inviteLink, setInviteLink] = useState<string>("");
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);

  const router = useRouter();

  // Fetch and load contacts
  useEffect(() => {
    if (user) {
      loadContacts();
    }
  }, [user]);

  const loadContacts = async () => {
    const data = await getContacts();
    setContacts(data);
  };

  // Fetch current user
  useEffect(() => {
    const fetchUser = async () => {
      const {
        data: { user: supaUser },
      } = await supabase.auth.getUser();
      if (supaUser) {
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("avatar_url, full_name, id")
          .eq("id", supaUser.id)
          .single();
        if (!profileError && profileData) {
          setUser(profileData as ExtendedUser);
        }
      }
    };
    fetchUser();

    // Track join time to filter messages
    setJoinTime(new Date().toISOString());

    // Fetch messages (if needed in the background)
    const fetchMessages = async () => {
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .order("created_at", { ascending: true })
        .gte("created_at", joinTime || new Date().toISOString());

      if (!error && data) {
        setMessages(data);
      }
    };
    fetchMessages();
  }, []);

  // Subscribe to realtime messages
  useEffect(() => {
    if (!user) return;

    const subscription = supabase
      .channel("public:messages")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages" },
        (payload) => {
          const newMessageObj: Message = {
            id: payload.new.id,
            content: payload.new.content,
            sender: payload.new.sender,
            created_at: payload.new.created_at,
          };
          setMessages((prevMessages) => [...prevMessages, newMessageObj]);

          // Play notification sound if the message sender is not the current user
          if (newMessageObj.sender !== user.full_name) {
            const audio = new Audio("/notification.mp3");
            audio.play().catch((error) =>
              console.error("Error playing notification sound:", error)
            );
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, [user]);

  // Fetch avatar URLs for unique message senders
  useEffect(() => {
    const fetchProfilesForMessages = async () => {
      const senders = Array.from(new Set(messages.map((m) => m.sender)));
      if (senders.length === 0) return;
      const { data, error } = await supabase
        .from("profiles")
        .select("full_name, avatar_url")
        .in("full_name", senders);
      if (!error && data) {
        const map: { [key: string]: string } = {};
        data.forEach((profile: { full_name: string; avatar_url: string }) => {
          map[profile.full_name] = profile.avatar_url;
        });
        setProfilesMap(map);
      }
    };
    if (messages.length > 0) {
      fetchProfilesForMessages();
    }
  }, [messages]);

  // Generate invite link
  const generateInviteLink = async () => {
    const generatedLink = `/join/${Math.random().toString(36).substr(2, 9)}`;
    setInviteLink(generatedLink);
  };

  // Handle contact selection
  const handleSelect = (contact: Contact): void => {
    setSelectedContact(contact);
  };

  // (Optional) open a private chat for a contact
  const handleOpenChat = async (contactId: string) => {
    router.push(`/chats/${contactId}`); // or handle however you'd like
  };

  // (Optional) send a message - not currently displayed in the UI
  const sendMessage = async () => {
    if (!newMessage.trim() || !user) return;
    await supabase.from("messages").insert([
      { content: newMessage, sender: user.full_name, sender_id: user.id },
    ]);
    setNewMessage("");
  };

  // Logout
  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (!error) {
      router.push("/");
    }
  };

  return (
    <div className="h-screen flex gap-1 w-full bg-gray-800">
      {/* Left Sidebar */}
      <div className="h-full flex gap-1 relative bg-gray-800">
        <div className="flex relative flex-col w-20 bg-black rounded-e-2xl justify-between">
          <HiMiniChatBubbleLeftRight className="text-gray-300 m-4 ml-5 animate-pulse text-5xl" />
          <div className="flex flex-col flex-grow items-center gap-8 mt-10">
            <div className="flex flex-col items-center text-gray-300 hover:text-white cursor-pointer">
              <BsChatSquareTextFill className="text-xl" />
              <span className="text-xs mt-2">All Chats</span>
            </div>
            <div className="flex flex-col items-center text-gray-300 hover:text-white cursor-pointer">
              <HiUserGroup className="text-xl" />
              <span className="text-xs mt-2">Communities</span>
            </div>
            <div className="flex flex-col items-center text-gray-300 hover:text-white cursor-pointer">
              <FaFolder className="text-xl" />
              <span className="text-xs mt-2">Work</span>
            </div>
            <div className="flex flex-col items-center text-gray-300 hover:text-white cursor-pointer">
              <HiMiniBellAlert className="text-xl" />
              <span className="text-xs mt-2">Alerts</span>
              <hr className="w-12 mt-6 border-gray-300" />
            </div>
            <div className="flex flex-col items-center text-gray-300 hover:text-white cursor-pointer">
              <IoBookmarks className="text-xl" />
              <span className="text-xs mt-2">Saved</span>
            </div>
          </div>

          {/* Settings Button */}
          <div className="p-2 bottom-2 mr-2 ml-1 mb-2">
            <button
              onClick={() => router.push('/chats/profile')}
              className="flex items-center"
            >
              <MdSettings className="size-6 text-gray-300 ml-3 mt-2 cursor-pointer hover:scale-105" />
            </button>
          </div>

          {/* Logout Button */}
          <div className="p-2 mr-2 mb-2">
            <BiLogOut
              className="size-6 text-red-600 ml-3 cursor-pointer hover:scale-105"
              onClick={handleLogout}
            />
          </div>
        </div>
      </div>

      {/* Contacts / Middle Column */}
      <div className="w-64 bg-gray-800 rounded-s-2xl p-2 flex-col">
        <div className="relative flex-1 mt-2">
          <div className="container mx-auto p-4">
            {/* Search Component */}
            <ContactsSearch />
          </div>

          <Button
            onClick={generateInviteLink}
            className="w-36 rounded-xl mt-5 ml-[20%] shadow-md bg-slate-600 hover:bg-slate-500 text-white font-semibold"
          >
            <RiChatNewLine /> New Chat
          </Button>

          <p className="mt-3 text-center text-sm text-gray-400">Invite link:</p>
          <p className="flex justify-center text-blue-500 underline">
            {inviteLink && (
              <a href={inviteLink} target="_blank" rel="noopener noreferrer">
                {inviteLink}
              </a>
            )}
          </p>
        </div>

        <div className="space-y-1 flex-1 mt-2 overflow-y-auto">
          <h2 className="text-xl mt-3 text-center p-2 font-bold mb-5 text-gray-300 rounded-xl">
            Messages
          </h2>
          <hr className="p-3 w-40 ml-10" />
          <div className="w-auto h-96 overflow-y-auto p-5">
            <ContactList contacts={contacts} userId={user?.id || ""} />
            <div className="flex-1 p-4"></div>
          </div>
        </div>
      </div>

      {/* Main Area (Introduction Page) */}
      <div className="flex-1 mt-2 flex flex-col px-3 bg-gray-800 rounded-2xl relative overflow-hidden">
  {/* Optional: You can add a background image here if desired */}
  <div className="flex-1 flex flex-col items-center justify-center text-white z-10 p-4">
    <motion.h1
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1.25 }}
      transition={{ duration: 1, ease: "easeOut" }}
      className="text-4xl font-bold mb-4"
    >
      Welcome to StockMarket Chat App
    </motion.h1>
    <motion.p
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1.25 }}
      transition={{ duration: 1, ease: "easeOut", delay: 0.2 }}
      className="text-md mt-8 text-gray-300 text-center max-w-lg"
    >
      Enhance team collaboration with secure and efficient real-time messaging.
      Communicate seamlessly with your colleagues, share updates, and stay
      productive—all in one place.
    </motion.p>
    
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8, delay: 1.2 }}
      className="mt-6 text-center"
    >
      <h2 className="text-2xl font-semibold text-gray-300 mt-2 mb-3">Key Features:</h2>
      <motion.ul
        initial="hidden"
        animate="visible"
        variants={{
          visible: {
            transition: {
              staggerChildren: 0.3,
            },
          },
        }}
        className="space-y-2"
      >
        {[
          "💬 Instant Messaging – Communicate with your team in real time.",
          "🔒 Secure & Private –  Ensures private conversations.",
          "📂 File Sharing – Share important documents, images, and reports effortlessly.",
          "🔔 Smart Notifications – Stay updated with important messages.",
        ].map((feature, index) => (
          <motion.li
            key={index}
            variants={{
              hidden: { opacity: 0, x: -20 },
              visible: { opacity: 1, x: 0 },
            }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="text-gray-400 text-md flex items-center"
          >
            <span className="mr-2">•</span>
            {feature}
          </motion.li>
        ))}
      </motion.ul>
    </motion.div>
    
    <motion.p
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: 2 }}
      className="mt-6 text-lg text-gray-200"
    >
      Boost workplace communication and productivity—start chatting now! 🚀
    </motion.p>
  </div>
</div>



    </div>
  );
};

export default ChatApp;
