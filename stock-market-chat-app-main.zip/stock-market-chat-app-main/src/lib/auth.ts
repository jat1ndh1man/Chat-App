import { supabase } from "./supabaseClient";

export const createUserProfile = async (userId: string, name: string, avatarUrl?: string) => {
    const { error } = await supabase.from("profiles").insert([
      { id: userId, name, avatar_url: avatarUrl || "" },
    ]);
  
    if (error) {
      console.error("Error creating profile:", error);
    }
  };
  