import { supabase } from "./supabaseClient";


export async function searchContacts(query: unknown) {
  const { data, error } = await supabase
    .from("users") // Replace with your actual users table
    .select("id, name, avatar_url") // Select relevant fields
    .ilike("name", `%${query}%`); // Case-insensitive search

  if (error) throw error;
  return data;
}

export const getContacts = async () => {
    const { data, error } = await supabase
    .from("profiles")
    .select("*"); // Fetch all columns
  
    if (error) {
      console.error("Error fetching contacts:", error.message || error);
      return [];
    }
  
    console.log("Fetched contacts:", data);
    return data || [];
  };
  